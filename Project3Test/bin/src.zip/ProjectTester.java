import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

/**
 * Tester for the project.
 * 
 * @author Patrick Muradaz
 * @version 12/2/19
 */
public class ProjectTester {

  @Test
  public void testProject() {
    assertTrue(true);
  }

}
